# VJApps website

Static site: `index.html`, `css/style.css`, `js/script.js`, `assets/`. No build step. Open `index.html` or upload the folder to any static host (GitHub Pages works).

## Configure (top of `js/script.js`)
- `formEndpoint`: URL from Formspree, Web3Forms or Getform. Without it the form opens the visitor's email app with the enquiry filled in, and says nothing is sent until they press Send.
- `email`: set to the support email shown on your Google Play listings. Change it if you want a different public address.
- `phone`, `social`, `privacyUrl`: add or replace as needed.
- `FACTS`: the figures under the hero, copied from Google Play (October 2026). Update them as they change.

## Apps
The `APPS` array holds your four Google Play apps (name, description, icon, screenshots, rating facts, Play link, privacy policy). Icons and screenshots load from Google Play's image servers. To add an app, copy an entry and use the image ids from its listing. For a permanent site, download the images into `assets/` and point `IMG` and the ids at your own files.

## Logo and colors
`assets/logo.png` is your supplied logo, cropped with its aspect ratio kept. Colors come from the logo: orange `#F86A20`, charcoal `#404040`, gray `#9B9B9B`. The gray is used for large text and rules only, because it is too light for small body text.

## Before launch
Add canonical and `og:url` tags for the real domain, and an Open Graph image at 1200x630.
